class NoMoreDemoDataException extends RuntimeException
{
  public NoMoreDemoDataException()
  {
    super();
  }

  public NoMoreDemoDataException(String message)
  {
    super(message);
  }
}
