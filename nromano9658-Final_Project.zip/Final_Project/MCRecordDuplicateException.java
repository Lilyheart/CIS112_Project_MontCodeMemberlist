class MCRecordDuplicateException extends RuntimeException
{
  public MCRecordDuplicateException()
  {
    super();
  }

  public MCRecordDuplicateException(String message)
  {
    super(message);
  }
}
