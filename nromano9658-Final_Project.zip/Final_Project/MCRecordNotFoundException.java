class MCRecordNotFoundException extends RuntimeException
{
  public MCRecordNotFoundException()
  {
    super();
  }

  public MCRecordNotFoundException(String message)
  {
    super(message);
  }
}
